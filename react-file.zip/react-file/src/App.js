import Page1 from './components/Page1/Page1';
// import Page1 from './components/Page1/Page1Tile';
// import Page2 from './components/Page2/Page2';
// import logo from './logo.svg';
// import data from './tiles.json';

import './App.css';

function App() {
  return (
    <Page1 />

    //  <Page2 />
  );
}

export default App;
