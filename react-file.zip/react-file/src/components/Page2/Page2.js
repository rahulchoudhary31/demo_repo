import React from "react";
import "./Page2.css";
// import "../../public/assets/css/style.css";

class Page1 extends React.Component {
  render() {
    return (
      <div>
      

<div class="container ">
  <div class="row">
    <div class="col-md-12 Logo"> <img src="assets/img/Logo.png" alt="logo" title="logo"/> </div>
  </div>



  <div className="Content">
              <div className="row">
                <div className="col-md-12 pt10  text-center"> <img className="width40" src="assets/img/Tittle.png" alt="Machine vison" title="Machine vison" /> </div>
              </div>
            </div>
  {/* <!-- Image Gallery  --> */}
  <div class="Gallery">
    <div class="container">
      <div class="leftArrow"> <a href="#"><img src="assets/img/Left-arrow.png" alt=" left Arrow"/></a> </div>
      <div class="RighttArrow"> <a href="#"><img src="assets/img/Right-arrow.png" alt="Right Arrow"/></a> </div>
      <div class="hover02 left-colums column-1"> <a href="#"><img src="assets/img/Safety-Equipment-Detection.png" alt="Industrial Machine vision"/></a>
        <div class="bottom-label"> Safety Equipment Detection </div>
      </div>
      <div class="hover02 left-colums column-2">
        <div class="upperBox"> <a href="#"><img src="assets/img/Distraction Detection.png" alt="" /></a>
          <div class="bottom-label"> Distraction Detection </div>
        </div>
        <div class="bottomrBox"> <a href="#"><img src="assets/img/Anomaly_Event_Detection.png" alt=""/></a>
          <div class="bottom-label"> Anomaly Event Detection </div>
        </div>
      </div>
      <div class="hover02 left-colums column-1"> <a href="#"><img src="assets/img/Health _and_ Wellness.png" alt=""/></a>
        <div class="bottom-label"> Health and Wellness </div>
      </div>
      <div class="hover02 left-colums column-2">
        <div class="upperBox"> <a href="#"><img src="assets/img/Accident_Detection.png" alt=""/></a>
          <div class="bottom-label">Accident Detection</div>
        </div>
        <div class="bottomrBox"> <a href="#"><img src="assets/img/Restricted_Zone Monitoring.png" alt=""/></a>
          <div class="bottom-label"> Restricted Zone Monitoring</div>
        </div>
      </div>
    </div>
  </div>
</div>


      </div>
    );
  }
}

export default Page1;