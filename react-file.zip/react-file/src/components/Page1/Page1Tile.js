
import React from "react";
import "./Page1.css";
import data from './tiles.json';

class Page1 extends React.Component {
  render() {
    return (
      <div>
       <h1>Hello React </h1>

       {data.map((tile, index)=>{
         return <div> 
          <h1>{tile.name}</h1>
         <div className="image-scroll">
         <img src={tile.url}></img>
         </div>
        </div>
       })}
         

      </div>
    );
  }
}

export default Page1;