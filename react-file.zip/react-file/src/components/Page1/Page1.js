
import React from "react";
import "./Page1.css";
// import "../../public/assets/css/style.css";
import  Page1Tile from "./Page1Tile";

class Page1 extends React.Component {
  render() {
    return (
      <div>
        {/* <h1>Hello React </h1> */}


        <div className="landingpageBG">
          <div className="container ">
            <div className="row">
              <div className="col-md-12 Logo"> <img src="assets/img/Logo.png" alt="logo" title="logo" /> </div>
            </div>
            <div className="Content">
              <div className="row">
                <div className="col-md-12 pt10  text-center"> <img className="width40" src="assets/img/Tittle.png" alt="Machine vison" title="Machine vison" /> </div>
              </div>
            </div>
            <header id="header">
              <div className="container">
                <div className="leftArrowHomepage"> <a href="#"><img src="assets/img/Left-arrow.png" /></a> </div>
                <div className="RighttArrowHomepage"> <a href="#"><img src="assets/img/Right-arrow.png" /></a> </div>
                <div className="hover02 column">
                   <div className="image-data">
                      <Page1Tile/>
                   </div>
                </div>
              </div>
            </header>
          </div>
        </div>



      </div>
    );
  }
}

export default Page1;